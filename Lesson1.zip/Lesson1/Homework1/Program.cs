﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework1
{
    class Program
    {
        static void Main(string[] args)
        {

            #region task 1
            Console.WriteLine("Task 1\n");
            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your surname: ");
            string surname = Console.ReadLine();
            Console.WriteLine("Enter your age: ");
            string age = Console.ReadLine();
            Console.WriteLine("Enter your growth: ");
            string growth = Console.ReadLine();
            Console.WriteLine("Enter your weight: ");
            string weight = Console.ReadLine();
            Console.WriteLine("Name: " + name + ", Surname: " + surname + ", Age: " + age + " years, Growth: " + growth + " sm, Weight: " + weight);
            Console.WriteLine("Name: {0}, Surname: {1}, Age: {2} years, Growth: {3} sm, Weight: {4}", name, surname, age, growth, weight);
            Console.WriteLine($"Name: {name}, Surname: {surname}, Age: {age} years, Growth: {growth} sm, Weight: {weight}");

            Console.ReadLine();
            #endregion

            #region task 2
            Console.WriteLine("Task 2\n");
            Console.WriteLine("Enter your growth: ");
            double h = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your weight: ");
            int m = int.Parse(Console.ReadLine());
            double L = m / (h * h);
            Console.WriteLine(L);

            Console.ReadLine();
            #endregion

            #region task 3
            Console.WriteLine("Task 3\n");
            Console.WriteLine("Enter x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());
            double r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            Console.WriteLine(string.Format("{0:F2}", r));
            Console.WriteLine();
            Console.WriteLine("Output method: ");
            double result = Hypotenuse(x1, x2, y1, y2);
            Console.WriteLine(string.Format("{0:F2}", result));

            Console.ReadLine();
            #endregion

            #region task 4
            Console.WriteLine("Task 4\n");
            Console.WriteLine("Whit third variable");
            int a = 4;
            int b = 1;
            Console.WriteLine($"a = {a}, b = {b}");
            int c = a;
            a = b;
            b = c;
            Console.WriteLine($"a = {a}, b = {b}");
            Console.WriteLine("Whitout third variable");
            a = 10;
            b = 20;
            Console.WriteLine($"a = {a}, b = {b}");
            a *= b;
            b = a / b;
            a /= b;
            Console.WriteLine($"a = {a}, b = {b}");

            Console.ReadLine();
            #endregion

            #region task 5
            Console.WriteLine("Task 5");
            Console.WriteLine("Maksim, Ardintsev, Kazan");
            Console.WriteLine(String.Format("{0," + Console.WindowWidth / 2 + "}", "Maksim, Ardintsev, Kazan"));

            Console.ReadLine();
            #endregion
        }


        static double Hypotenuse(double a, double b, double c, double d) {
            return Math.Sqrt(Math.Pow(b-a,2) + Math.Pow(d-c,2));
        }
    }
}
